
package binaryst;

import java.util.LinkedList;
import java.util.Queue;



public class BinaryST {
   BSTNode root;
   int count;
   BinaryST(){
   root=null;
   }
   public BSTNode insert(BSTNode root,int key){
       if(this.root==null){
       this.root=new BSTNode(key);
       count=1;
       return root;
       }
       if(root==null ){
           count++;
           return new BSTNode(key);
       
       }
       if(root.value==key){
           return root;
     }
       if(key<root.value){
       root.left=insert(root.left,key);
       }
       if(key>root.value){
       root.right=insert(root.right,key);
       }
       return root;
   }
  public boolean searchNode(BSTNode root, int key) {
        if (root == null) {
            return false;
        }
        if (root.value == key) {
            return true; // Key found
        }
        if (key < root.value) {
            return searchNode(root.left, key);
        }
        return searchNode(root.right, key);
    }
   public void inordertraversal(BSTNode root){
      if(root!=null){
       inordertraversal(root.left);
       System.out.print(" "+root.value);
       inordertraversal(root.right);
       } 
   }
    public void preordertraversal(BSTNode root){
      if(root!=null){
           System.out.print(" "+root.value);
       inordertraversal(root.left);
      
       inordertraversal(root.right);
       } 
   }
     public void postordertraversal(BSTNode root){
      if(root!=null){
       inordertraversal(root.left);
       inordertraversal(root.right);
         System.out.print(" "+root.value);
       } 
   }
     public void levelordertraversal(){
    if(root==null){
    return;
    }
    Queue<BSTNode> queue=new LinkedList<>();
    queue.add(root);
    while(!queue.isEmpty()){
        BSTNode current=queue.remove();
        System.out.print(current.value+" ");
        if(current.left!=null){
        queue.add(current.left);
         }
        if(current.right!=null){
          queue.add(current.right);
        }
    }
}
    public BSTNode deleteNode(BSTNode root, int key) {
        if (key < root.value) {
            root.left = deleteNode(root.left, key);

        } else if (root.value < key) {
            root.right = deleteNode(root.right, key);
        } else {
               
            if (root.left == null) {
                return root.right;
            }
            if (root.right == null) {
                return root.left;
            }
            if (root.left != null && root.right != null) {
                BSTNode succesor;
                succesor = getSuccessor(root);
                root.value = succesor.value;
                root.right = deleteNode(root.right, succesor.value);
                
            }
            count--;
        }
        return root;
    }
    private BSTNode getSuccessor(BSTNode root) {
        BSTNode current = root.right;
        while (current != null && current.left != null) {
            current = current.left;
        }
        return current;
    }
  public int countNodes() {
    
      return count;
      
 }
    
    public static void main(String[] args) {
       BinaryST tree=new BinaryST();
       tree.insert(tree.root, 10);
       tree.insert(tree.root, 50);
       tree.insert(tree.root, 5);
       tree.insert(tree.root, 15);
       tree.insert(tree.root, 20);
       tree.insert(tree.root, 1);
        System.out.println("inorder :");
       tree.inordertraversal(tree.root);
       tree.deleteNode(tree.root, 10);
        System.out.println("\nAfter deleting: "+10);
       tree.inordertraversal(tree.root);
        System.out.println("");
        System.out.println("total nodes: "+tree.countNodes());
        System.out.println();
        System.out.println((tree.searchNode(tree.root, 1)) ? "Found" : "Not found");
        System.out.println("preorder:");
        tree.preordertraversal(tree.root);
        System.out.println("\npostorder: ");
        tree.postordertraversal(tree.root);
        System.out.println("\nLevel order");
        tree.levelordertraversal();
    }
   
}
