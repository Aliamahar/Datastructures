/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package binaryt;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author ESHOP
 */
public class BinaryT {
  BTNode root;
  BinaryT(){
      root=null;
  }
    
  public void inorderTraversal(BTNode root){
      if(root==null){
      return;
      }
      inorderTraversal(root.left);
      System.out.print(" "+ root.data);
      inorderTraversal(root.right);
      
  }
   public void preorderTraversal(BTNode root){
      if(root==null){
      return;
      }
       System.out.print(" "+ root.data);
      preorderTraversal(root.left);
      preorderTraversal(root.right);
      
  }
    public void postorderTraversal(BTNode root){
      if(root==null){
      return;
      }
      preorderTraversal(root.left);
      preorderTraversal(root.right);
      System.out.print(" "+ root.data);
     
      
  }
    public void levelorder(BTNode root){
        Queue<BTNode> queue=new LinkedList<>();
        queue.add(root);
        
        while(!queue.isEmpty()){
            
            BTNode current=queue.remove();
            System.out.print(" "+current.data);
            
            if(current.left!=null){
            queue.add(current.left);
            }
            
             if(current.right!=null){
            queue.add(current.right);
            }
        }
    }
    public static void main(String[] args) {
       BinaryT n1=new BinaryT();
       n1.root=new BTNode(1);
       BTNode n2=new BTNode(2);
        BTNode n3=new BTNode(3);
       n1.root.addleftchild(n1.root, n2);
       n1.root.addrightchild(n1.root, n3);
        BTNode n4=new BTNode(4);
         BTNode n5=new BTNode(5);
          BTNode n6=new BTNode(6);
          n2.addleftchild(n2, n4);
          n2.addrightchild(n2, n5);
          n3.addrightchild(n3, n6);
          System.out.println("inorder");
         n1.inorderTraversal(n1.root);
         System.out.println("\npreorder");
         n1.preorderTraversal(n1.root);
         System.out.println("\npostorder");
         n1.postorderTraversal(n1.root);
         System.out.println("");
        System.out.println("\nlevelorder");
        n1.levelorder(n1.root);
    }
    
}
